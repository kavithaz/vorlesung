CREATE TABLE notes (
  id BIGINT NOT NULL AUTO_INCREMENT PRIMARY KEY,
  title VARCHAR(255) NOT NULL,
  content VARCHAR(255) NOT NULL,
  created DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

INSERT INTO notes (title, content, created, updated) VALUES
	('Bemerkung 1', 'Inhalt 1', '2018-10-15 17:02:52', '2018-10-15 17:02:52'),
	('Bemerkung 2', 'Inhalt 2', '2018-10-15 17:03:11', '2018-10-15 17:03:11'),
	('Bemerkung 3', 'Inhalt 3', '2018-10-15 17:03:24', '2018-10-15 17:03:24'),
	('Bemerkung 4', 'Inhalt 4', '2018-10-15 17:03:34', '2018-10-15 17:03:34'),
	('Bemerkung 5', 'Inhalt 5', '2018-10-24 17:25:54', '2018-10-24 17:25:54'),
	('Bemerkung 6', 'Inhalt 6', '2018-10-24 17:29:38', '2018-10-24 17:29:38');